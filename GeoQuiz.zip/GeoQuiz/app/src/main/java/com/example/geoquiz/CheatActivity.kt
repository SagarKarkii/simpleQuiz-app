package com.example.geoquiz

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewAnimationUtils
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class CheatActivity : AppCompatActivity() {
    private var AnswerIsTrue = false
    private var HasCheated = false
    private var AnswerTextView: TextView? = null
    private var ShowAnswer: Button? = null
    private var apiLevel: String? = null
    private var apiLevelTW: TextView? = null
    fun showAnswer() {
        if (!AnswerIsTrue) {
            AnswerTextView!!.setText(R.string.false_button)
        } else {
            AnswerTextView!!.setText(R.string.true_button)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cheat)
        apiLevel = getString(R.string.api) + " " + Build.VERSION.SDK_INT
        apiLevelTW = findViewById<View>(R.id.api) as TextView
        apiLevelTW!!.text = apiLevel
        AnswerIsTrue = intent.getBooleanExtra(EXTRA_ANSWER_IS_TRUE, false)
        AnswerTextView = findViewById<View>(R.id.answer_text_view) as TextView
        ShowAnswer = findViewById<View>(R.id.show_answer_button) as Button
        ShowAnswer!!.setOnClickListener {
            if (AnswerIsTrue) {
                AnswerTextView!!.setText(R.string.true_button)
            } else {
                AnswerTextView!!.setText(R.string.false_button)
            }
            setAnswerShownResult(true)
            HasCheated = true

            //Animation
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val cx = ShowAnswer!!.width / 2
                val cy = ShowAnswer!!.height / 2
                val radius = ShowAnswer!!.width.toFloat()
                val anim = ViewAnimationUtils.createCircularReveal(ShowAnswer, cx, cy, radius, 0f)
                anim.addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) {
                        super.onAnimationEnd(animation)
                        AnswerTextView!!.visibility = View.VISIBLE
                        ShowAnswer!!.visibility = View.INVISIBLE
                    }
                })
                anim.start()
            } else {
                AnswerTextView!!.visibility = View.VISIBLE
                ShowAnswer!!.visibility = View.INVISIBLE
            }
        }
        if (savedInstanceState != null) {
            AnswerIsTrue = savedInstanceState.getBoolean(ANSWER, false)
            HasCheated = savedInstanceState.getBoolean(CHEATER, false)
            if (HasCheated) {
                setAnswerShownResult(true)
                if (AnswerIsTrue) {
                    AnswerTextView!!.setText(R.string.true_button)
                } else {
                    AnswerTextView!!.setText(R.string.false_button)
                }
            }
        }
    }

    public override fun onSaveInstanceState(savedInstanceState: Bundle) {
        super.onSaveInstanceState(savedInstanceState)
        Log.i(NAME, "in onSavedInstanceState")
        savedInstanceState.putBoolean(CHEATER, HasCheated)
        savedInstanceState.putBoolean(ANSWER, AnswerIsTrue)
    }

    private fun setAnswerShownResult(isAnswerShown: Boolean) {
        val data = Intent()
        data.putExtra(EXTRA_ANSWER_SHOWN, isAnswerShown)
        setResult(RESULT_OK, data)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_cheat, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id = item.itemId
        return if (id == R.id.action_settings) {
            true
        } else super.onOptionsItemSelected(item)
    }

    companion object {
        private const val EXTRA_ANSWER_IS_TRUE = "com.example.geoquiz.answer_is_true"
        private const val EXTRA_ANSWER_SHOWN = "com.example.geoquiz.answer_shown"
        private const val ANSWER = "cheated_answer"
        private const val CHEATER = "cheater"
        private const val NAME = "CheatActivity"
        fun newIntent(packageContext: Context?, answerIsTrue: Boolean): Intent {
            val i = Intent(packageContext, CheatActivity::class.java)
            i.putExtra(EXTRA_ANSWER_IS_TRUE, answerIsTrue)
            return i
        }

        fun wasAnswerShown(result: Intent): Boolean {
            return result.getBooleanExtra(EXTRA_ANSWER_SHOWN, false)
        }
    }
}