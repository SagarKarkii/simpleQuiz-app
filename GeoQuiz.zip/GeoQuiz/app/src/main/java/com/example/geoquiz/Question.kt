package com.example.geoquiz

class Question(var textResId: Int, var isAnswerTrue: Boolean)