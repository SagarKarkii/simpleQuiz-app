package com.example.geoquiz

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private var TrueButton: Button? = null
    private var FalseButton: Button? = null
    private var NextButton: ImageButton? = null
    private var PrevButton: ImageButton? = null
    private var CheatButton: Button? = null
    private var QuestionTextView: TextView? = null
    private val QuestionBank: Array<Question> = arrayOf<Question>(
        Question(R.string.question_australia, true),
        Question(R.string.question_russia, false),
        Question(R.string.question_mountain, false),
        Question(R.string.question_scotland, true),
        Question(R.string.question_india, true),
    )
    private var CheatingBank: IntArray? = intArrayOf(0, 0, 0, 0, 0, 0, 0, 0, 0, 0)
    private var CurrentIndex = 0
    private var IsCheater = false
    private fun updateQuestion() {
        val questionTextResId = QuestionBank[CurrentIndex].textResId
        QuestionTextView!!.setText(questionTextResId)
    }

    private fun checkAnswer(userPressedTrue: Boolean) {
        val answerIsTrue: Boolean = QuestionBank[CurrentIndex].isAnswerTrue
        var messageResId = 0
        if (IsCheater) {
            messageResId = R.string.judgement_toast
        } else {
            if (userPressedTrue == answerIsTrue) {
                if (CheatingBank!![CurrentIndex] != 1) {
                    messageResId = R.string.correct_toast
                } else if (CheatingBank!![CurrentIndex] == 1) {
                    messageResId = R.string.judgement_toast
                }
            } else {
                if (CheatingBank!![CurrentIndex] != 1) {
                    messageResId = R.string.incorrect_toast
                } else if (CheatingBank!![CurrentIndex] == 1) {
                    messageResId = R.string.judgement_toast
                }
            }
        }
        Toast.makeText(this, messageResId, Toast.LENGTH_SHORT)
            .show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate(Bundle called")
        setContentView(R.layout.activity_main)
        QuestionTextView = findViewById<View>(R.id.question_text_view) as TextView
        TrueButton = findViewById<View>(R.id.true_button) as Button
        TrueButton!!.setOnClickListener { checkAnswer(true) }
        FalseButton = findViewById<View>(R.id.false_button) as Button
        FalseButton!!.setOnClickListener { checkAnswer(false) }
        NextButton = findViewById<View>(R.id.next_button) as ImageButton
        NextButton!!.setOnClickListener {
            CurrentIndex = (CurrentIndex + 1) % QuestionBank.size
            IsCheater = false
            updateQuestion()
        }
        PrevButton = findViewById<View>(R.id.prev_button) as ImageButton
        PrevButton!!.setOnClickListener {
            if (CurrentIndex > 0) {
                CurrentIndex = (CurrentIndex - 1) % QuestionBank.size
                updateQuestion()
            } else if (CurrentIndex == 0) {
                CurrentIndex = (QuestionBank.size - 1) % QuestionBank.size
                updateQuestion()
            }
        }
        CheatButton = findViewById<View>(R.id.cheat_button) as Button
        CheatButton!!.setOnClickListener { //Start CheatActivity
            val answerIsTrue: Boolean = QuestionBank[CurrentIndex].isAnswerTrue
            val i: Intent = CheatActivity.newIntent(this@MainActivity, answerIsTrue)
            startActivityForResult(i, REQUEST_CODE_CHEAT)
        }
        QuestionTextView!!.setOnClickListener {
            CurrentIndex = (CurrentIndex + 1) % QuestionBank.size
            updateQuestion()
        }
        if (savedInstanceState != null) {
            CurrentIndex = savedInstanceState.getInt(KEY_INDEX, 0)
            IsCheater = savedInstanceState.getBoolean(CHEATER, false)
            CheatingBank = savedInstanceState.getIntArray(QUESTIONS_CHEATED)
        }
        updateQuestion()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) {
            return
        }
        if (requestCode == REQUEST_CODE_CHEAT) {
            if (data == null) {
                return
            }
            IsCheater = CheatActivity.wasAnswerShown(data)
        }
        if (IsCheater) {
            CheatingBank!![CurrentIndex] = 1
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.i(TAG, "onSaveInstanceState")
        outState.putInt(KEY_INDEX, CurrentIndex)
        outState.putBoolean(CHEATER, IsCheater)
        outState.putIntArray(QUESTIONS_CHEATED, CheatingBank)
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart(Bundle called")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause(Bundle called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume(Bundle called")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop(Bundle called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy(Bundle called")
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_quiz, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return if (id == R.id.action_settings) {
            true
        } else super.onOptionsItemSelected(item)
    }

    companion object {
        const val TAG = "MainActivity"
        const val KEY_INDEX = "index"
        const val CHEATER = "cheater"
        const val QUESTIONS_CHEATED = "questions_cheated"
        const val REQUEST_CODE_CHEAT = 0
    }
}

private fun TextView.setText(question: Unit) {

}

private fun Question.getTextResId() {

}
